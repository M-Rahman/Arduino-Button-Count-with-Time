# Arduino-Absolute-ButtonPress-Count
Absolute button press count for Arduino with Debouncing time.

Default code was implemented with only 4 button, user may connect upto-intended button and assign the pins accordingly. 
